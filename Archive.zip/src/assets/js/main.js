document.addEventListener('DOMContentLoaded', function () {
    console.log(1)
});